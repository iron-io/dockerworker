hello_worker
============

For ruby, use bundle install --standalone

Then add this to your worker: require_relative 'vendor/bundle/bundler/setup'

